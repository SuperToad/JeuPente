public class Principal 
{
	public static void main(String[] args)
	{
		FenetrePrincipale fen = new FenetrePrincipale("Jeu de Pente");
	}
}
